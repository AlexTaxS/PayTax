from setuptools import setup

setup(
    name='main2',
    version='1.0',
    description='The Head First Python Tax Tools',
    author='AV Vladi',
    author_email='info@consultpartner.ru',
    url='ipnalogru.ru',
    py_modules=['main2', 'forms'],
)
